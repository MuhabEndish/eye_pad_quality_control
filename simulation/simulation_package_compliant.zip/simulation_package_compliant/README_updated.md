# Medikal Ürün Kalite Kontrolü Simülasyonu - Kullanım Kılavuzu

Bu doküman, Python ve OpenCV kullanarak geliştirilen medikal ürün kalite kontrolü simülasyonunun kurulum ve kullanım talimatlarını içermektedir.

## Gereksinimler

Simülasyonu çalıştırmak için aşağıdaki yazılımlara ihtiyacınız vardır:

- Python 3.6 veya daha yeni bir sürüm
- Pygame kütüphanesi
- OpenCV kütüphanesi
- NumPy kütüphanesi

## Kurulum

1. Python'u bilgisayarınıza kurun (https://www.python.org/downloads/)
2. Gerekli kütüphaneleri yükleyin:

```bash
pip install -r requirements.txt
```

3. Simülasyon dosyalarını bilgisayarınıza indirin

## Çalıştırma

1. Komut satırında simülasyon klasörüne gidin:

```bash
cd /path/to/python_simulation
```

2. Ana uygulamayı çalıştırın:

```bash
python simulation_all_in_one_windows.py
```

## Kullanım

### Simülasyon Kontrolleri

- **Başlat**: Simülasyonu başlatır ve ürün üretimini aktifleştirir
- **Durdur**: Simülasyonu duraklatır
- **Sıfırla**: Tüm istatistikleri ve ürünleri sıfırlar

### Hata Oranı Ayarı

Kullanıcı arayüzündeki sürgü ile kabul edilebilir hata oranını ayarlayabilirsiniz:

- Sürgüyü sağa kaydırdıkça hata oranı eşiği artar (daha fazla ürün "sağlam" olarak kabul edilir)
- Sürgüyü sola kaydırdıkça hata oranı eşiği azalır (daha fazla ürün "hatalı" olarak kabul edilir)
- Eğer bir ürünün hata oranı, belirlenen eşik değerinden yüksekse "hatalı" olarak sınıflandırılır
- Eğer bir ürünün hata oranı, belirlenen eşik değerinden düşükse "sağlam" olarak sınıflandırılır

### İstatistikler

Simülasyon sırasında aşağıdaki istatistikler gerçek zamanlı olarak görüntülenir:

- Toplam üretilen ürün sayısı
- Tespit edilen hatalı ürün sayısı
- Doğru şekilde ayrıştırılan ürün sayısı
- Mevcut hata oranı
- Dakikada işlenen ürün sayısı (FPS ölçümü)
- Çalışma süresi

## Simülasyon Bileşenleri

### Üretim Bandı

Ekranın ortasında görünen gri renkli konveyör bant, ürünlerin soldan sağa doğru hareket ettiği ana üretim hattıdır.

### Tarama Noktası

Ekranın ortasındaki kırmızı dikey çizgi, ürünlerin görüntü işleme ile tarandığı noktayı gösterir.

### Ayrıştırma Mekanizması

Tarama noktasından sonra, ürünler hatalı veya sağlam olarak ayrıştırılır:
- Yeşil hat: Sağlam ürünlerin yolu
- Kırmızı hat: Hatalı ürünlerin yolu

### Göz Pedleri

Simülasyonda dört farklı hata türü bulunmaktadır:
1. **Renk Değişimi**: Sararmış veya rengi değişmiş bölgeler
2. **Leke**: Yüzeyde lekeler
3. **Yapısal Bozulma**: Şekil bozuklukları
4. **Kesim Hatası**: Asimetrik veya hatalı kesim

## Algoritma Karmaşıklığı (Big-O Notasyonu)

Simülasyonda kullanılan temel algoritmaların karmaşıklık analizi:

- **ImageProcessor.process()**: 
  - Zaman Karmaşıklığı: O(1) - Sabit zamanlı işlem
  - Mekân Karmaşıklığı: O(1) - Sabit bellek kullanımı

- **Ürün Üretimi**: O(1) - Sabit zamanlı işlem
- **Konveyör Hareketi**: O(n) - n, bant üzerindeki ürün sayısı
- **Hata Tespiti**: O(1) - Ürün başına sabit zamanlı işlem
- **Ayrıştırma Mekanizması**: O(1) - Ürün başına sabit zamanlı işlem
- **İstatistik Hesaplama**: O(1) - Sabit zamanlı güncelleme

Genel Mekân Karmaşıklığı: O(n) - n, simülasyondaki toplam ürün sayısı

## FPS Ölçümü

Simülasyon, varsayılan ayarlarda dakikada yaklaşık 30 ürün işleyebilmektedir. Bu değer, ekranın sağ alt köşesindeki istatistik panelinde "Urun/Dakika" olarak gösterilmektedir.

Kullanılan kamera: Simülasyon içinde sanal kamera (OpenCV ile oluşturulan görüntüler)

## Demo Videosu

Simülasyonun çalışmasını gösteren demo videosu için aşağıdaki bağlantıyı kullanabilirsiniz:

[Demo Video Bağlantısı](https://youtu.be/DEMO_VIDEO_ID)

*Not: Lütfen bu bağlantıyı kendi hazırladığınız demo videosunun bağlantısı ile değiştirin.*

## GitHub Repo Yapısı ve Etiketleme

Projeyi GitHub'a yüklerken aşağıdaki yapıyı kullanmanız önerilir:

```
/TAKIM_ADI/
  ├── simulation_all_in_one.py
  ├── requirements.txt
  ├── README.md
  └── demo_video.mp4 (opsiyonel)
```

GitHub'a yüklerken mutlaka `#ttg5hackathon2025` etiketini kullanın.

## Sorun Giderme

Eğer simülasyon çalışmazsa:

1. Python ve gerekli kütüphanelerin doğru şekilde kurulduğundan emin olun
2. Tüm simülasyon dosyalarının aynı klasörde olduğunu kontrol edin
3. Hata mesajlarını inceleyerek eksik kütüphaneleri yükleyin

## Hackathon Gereksinimleri Uyumu

Bu simülasyon, Turgutlu Teknoloji Günleri - 5 Hackathonu için istenen aşağıdaki gereksinimleri karşılamaktadır:

- Görüntü İşleme ile Tanıma: OpenCV kullanılarak ürünlerin tanınması
- Parça Bazlı Kontrol: Farklı hata türlerinin tespiti
- Sağlamlık Tespiti: Yapısal bozulmaların kontrolü
- Renk ve Leke Tespiti: Renk değişimi ve lekelerin tespiti
- Simülasyon Ortamı: Pygame ile gerçekçi üretim bandı simülasyonu
- Kullanıcı Etkileşimi: Hata oranı eşiği ayarı ve kontrol paneli

## İletişim

Sorularınız veya geri bildirimleriniz için lütfen iletişime geçin.
