
try:
    #!/usr/bin/env python3
    # -*- coding: utf-8 -*-
    # Medikal Urun Kalite Kontrolu Simulasyonu - Tum Kod Tek Dosyada
    # Turgutlu Teknoloji Gunleri - 5 Hackathonu icin hazirlanmistir
    
    import pygame
    import pygame.freetype
    import cv2
    import numpy as np
    import random
    import time
    import sys
    import os
    
    # ---- STATS CLASS ----
    class Stats:
        def __init__(self):
            self.total_products = 0
            self.defective_products = 0
            self.correctly_sorted = 0
            self.current_error_rate = 0.0
            
            # FPS ve urun isleme olcumleri
            self.start_time = time.time()
            self.products_per_minute = 0
            self.last_minute_check = time.time()
            self.minute_counter = 0
        
        def update(self, is_defective, sorted_as_defective):
            # Toplam urun sayisini guncelle
            self.total_products += 1
            self.minute_counter += 1
            
            # Hatali urun sayisini guncelle
            if is_defective:
                self.defective_products += 1
            
            # Dogru ayristirma sayisini guncelle
            if (is_defective and sorted_as_defective) or (not is_defective and not sorted_as_defective):
                self.correctly_sorted += 1
            
            # Hata oranini guncelle
            if self.total_products > 0:
                self.current_error_rate = (self.defective_products / self.total_products) * 100.0
                
            # FPS olcumu (her dakika)
            current_time = time.time()
            if current_time - self.last_minute_check >= 60:
                self.products_per_minute = self.minute_counter
                self.minute_counter = 0
                self.last_minute_check = current_time
        
        def reset(self):
            # İstatistikleri sifirla
            self.total_products = 0
            self.defective_products = 0
            self.correctly_sorted = 0
            self.current_error_rate = 0.0
            
            # FPS olcumlerini sifirla
            self.start_time = time.time()
            self.products_per_minute = 0
            self.last_minute_check = time.time()
            self.minute_counter = 0
            
        def get_runtime(self):
            return time.time() - self.start_time
    
    # ---- UI CLASS ----
    class UI:
        def __init__(self, screen):
            self.screen = screen
            self.width = screen.get_width()
            self.height = screen.get_height()
            
            # Font
            pygame.freetype.init()
            self.font = pygame.freetype.SysFont("Arial", 16)
            self.title_font = pygame.freetype.SysFont("Arial", 24, bold=True)
            
            # Kontrol paneli
            self.panel_x = 50
            self.panel_y = 50
            self.panel_width = self.width - 100
            self.panel_height = 100
            
            # Dugmeler
            self.buttons = {
                "start": pygame.Rect(self.panel_x + 10, self.panel_y + 10, 100, 30),
                "stop": pygame.Rect(self.panel_x + 120, self.panel_y + 10, 100, 30),
                "reset": pygame.Rect(self.panel_x + 230, self.panel_y + 10, 100, 30)
            }
            
            # Hata orani surgusu
            self.slider_x = self.panel_x + 350
            self.slider_y = self.panel_y + 25
            self.slider_width = 200
            self.slider_height = 10
            self.slider_knob_radius = 10
            self.slider_knob_pos = 0.02 * self.slider_width  # %2 varsayilan
            self.slider_dragging = False
            
            # İstatistik paneli
            self.stats_x = 50
            self.stats_y = self.height - 150
            self.stats_width = self.width - 100
            self.stats_height = 100
        
        def handle_event(self, event):
            # Fare tiklamasi
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                
                # Dugme kontrolleri
                if self.buttons["start"].collidepoint(pos):
                    return "start"
                elif self.buttons["stop"].collidepoint(pos):
                    return "stop"
                elif self.buttons["reset"].collidepoint(pos):
                    return "reset"
                
                # Surgu kontrolu
                slider_rect = pygame.Rect(self.slider_x, self.slider_y - 5, self.slider_width, self.slider_height + 10)
                if slider_rect.collidepoint(pos):
                    self.slider_dragging = True
                    self.slider_knob_pos = min(max(0, pos[0] - self.slider_x), self.slider_width)
                    return "threshold_changed"
            
            # Fare birakma
            elif event.type == pygame.MOUSEBUTTONUP:
                if self.slider_dragging:
                    self.slider_dragging = False
                    return "threshold_changed"
            
            # Fare hareketi
            elif event.type == pygame.MOUSEMOTION:
                if self.slider_dragging:
                    pos = pygame.mouse.get_pos()
                    self.slider_knob_pos = min(max(0, pos[0] - self.slider_x), self.slider_width)
                    return "threshold_changed"
            
            return None
        
        def get_error_threshold(self):
            # Surgu pozisyonundan hata oranini hesapla (0-10%)
            return (self.slider_knob_pos / self.slider_width) * 10.0
        
        def draw(self, stats):
            # Kontrol paneli
            pygame.draw.rect(
                self.screen,
                (220, 220, 220),
                (self.panel_x, self.panel_y, self.panel_width, self.panel_height),
                0,
                10
            )
            
            # Baslik
            self.title_font.render_to(
                self.screen,
                (self.width // 2 - 200, 20),
                "Medikal Urun Kalite Kontrolu Simulasyonu",
                (0, 0, 0)
            )
            
            # Dugmeler
            for name, rect in self.buttons.items():
                color = (100, 200, 100) if name == "start" else (200, 100, 100) if name == "stop" else (100, 100, 200)
                pygame.draw.rect(self.screen, color, rect, 0, 5)
                
                text = "Baslat" if name == "start" else "Durdur" if name == "stop" else "Sifirla"
                text_rect = self.font.get_rect(text)
                text_rect.center = rect.center
                self.font.render_to(self.screen, text_rect, text, (255, 255, 255))
            
            # Hata orani surgusu
            pygame.draw.rect(
                self.screen,
                (150, 150, 150),
                (self.slider_x, self.slider_y, self.slider_width, self.slider_height),
                0,
                5
            )
            
            pygame.draw.circle(
                self.screen,
                (50, 50, 200),
                (self.slider_x + self.slider_knob_pos, self.slider_y + self.slider_height // 2),
                self.slider_knob_radius
            )
            
            # Hata orani etiketi
            error_threshold = self.get_error_threshold()
            self.font.render_to(
                self.screen,
                (self.slider_x, self.slider_y - 20),
                f"Hata Orani Esigi: %{error_threshold:.1f}",
                (0, 0, 0)
            )
            
            # İstatistik paneli
            pygame.draw.rect(
                self.screen,
                (220, 220, 220),
                (self.stats_x, self.stats_y, self.stats_width, self.stats_height),
                0,
                10
            )
            
            # İstatistikler
            stats_texts = [
                f"Toplam Urun: {stats.total_products}",
                f"Hatali Urun: {stats.defective_products}",
                f"Dogru Ayristirma: {stats.correctly_sorted}",
                f"Mevcut Hata Orani: %{stats.current_error_rate:.2f}",
                f"Urun/Dakika: {stats.products_per_minute}",
                f"Calisma Suresi: {int(stats.get_runtime())} saniye"
            ]
            
            for i, text in enumerate(stats_texts):
                self.font.render_to(
                    self.screen,
                    (self.stats_x + 20, self.stats_y + 20 + i * 20),
                    text,
                    (0, 0, 0)
                )
            
            # Hata orani cubugu
            bar_width = 200
            bar_height = 15
            bar_x = self.stats_x + self.stats_width - bar_width - 20
            bar_y = self.stats_y + 40
            
            # Arka plan
            pygame.draw.rect(
                self.screen,
                (200, 200, 200),
                (bar_x, bar_y, bar_width, bar_height),
                0,
                5
            )
            
            # Dolgu
            fill_width = min(bar_width, int(bar_width * stats.current_error_rate / 10.0))
            color = (0, 200, 0) if stats.current_error_rate <= error_threshold else (200, 0, 0)
            pygame.draw.rect(
                self.screen,
                color,
                (bar_x, bar_y, fill_width, bar_height),
                0,
                5
            )
    
    # ---- SORTER CLASS ----
    class Sorter:
        def __init__(self, screen):
            self.screen = screen
            self.width = screen.get_width()
            self.height = screen.get_height()
            
            # Ayristirma noktasi
            self.sort_point_x = self.width // 2 + 100
            self.sort_point_y = self.height // 2
            
            # Ayristirma yollari
            self.good_path_y = self.height // 2
            self.defect_path_y = self.height // 2 + 100
            
            # Ayristirilan urunler
            self.sorted_products = []
        
        def sort_product(self, product, as_defective):
            # Urunu ayristir
            product.sorted = True
            product.sorted_as_defective = as_defective
            
            # Ayristirilan urunler listesine ekle
            self.sorted_products.append(product)
        
        def reset(self):
            # Ayristirilan urunleri temizle
            self.sorted_products = []
        
        def draw(self):
            # Ayristirma yollarini ciz
            pygame.draw.line(
                self.screen,
                (0, 200, 0),
                (self.sort_point_x, self.sort_point_y),
                (self.width, self.good_path_y),
                3
            )
            
            pygame.draw.line(
                self.screen,
                (200, 0, 0),
                (self.sort_point_x, self.sort_point_y),
                (self.width, self.defect_path_y),
                3
            )
            
            # Ayristirma noktasini ciz
            pygame.draw.circle(
                self.screen,
                (0, 0, 200),
                (self.sort_point_x, self.sort_point_y),
                5
            )
    
    # ---- IMAGE PROCESSOR CLASS ----
    class ImageProcessor:
        def __init__(self):
            # Goruntu isleme parametreleri
            self.accuracy = 0.9  # %90 dogruluk
        
        def process(self, product):
            # Gercek bir goruntu isleme sistemi burada urun goruntusunu analiz ederdi
            # Bu simulasyonda, urunun gercek durumunu biliyoruz ve buna gore simule ediyoruz
            # Zaman Karmasikligi: O(1) - sabit zamanli islem
            # Mekân Karmasikligi: O(1) - sabit bellek kullanimi
            
            # Gercek durumu biliyoruz (simulasyon icin)
            is_defective = product.is_defective
            defect_type = product.defect_type
            defect_severity = product.defect_severity
            
            # Simule edilmis goruntu isleme sonucu
            detected_as_defective = False
            detected_defect_type = 0
            detected_defect_percentage = 0.0
            
            if is_defective:
                # Dogru pozitif orani (gercekten hatali urunu hatali olarak tespit etme)
                if random.random() < self.accuracy:
                    detected_as_defective = True
                    detected_defect_type = defect_type
                    # Gercek siddet degerini biraz gurultu ile simule et
                    noise = random.uniform(-0.1, 0.1)
                    detected_defect_percentage = max(0, min(100, defect_severity * 100 + noise * 100))
                else:
                    # Yanlis negatif (hatali urunu saglam olarak tespit etme)
                    detected_as_defective = False
                    detected_defect_percentage = random.uniform(0, 1.5)  # Dusuk hata yuzdesi
            else:
                # Yanlis pozitif orani (saglam urunu hatali olarak tespit etme)
                if random.random() < (1 - self.accuracy):
                    detected_as_defective = True
                    detected_defect_type = random.randint(0, 3)
                    detected_defect_percentage = random.uniform(2.0, 5.0)  # Dusuk-orta hata yuzdesi
                else:
                    # Dogru negatif (saglam urunu saglam olarak tespit etme)
                    detected_as_defective = False
                    detected_defect_percentage = random.uniform(0, 1.0)  # Cok dusuk hata yuzdesi
            
            # Sonuclari dondur
            return {
                "is_defective": detected_as_defective,
                "defect_type": detected_defect_type,
                "defect_percentage": detected_defect_percentage,
                "confidence": random.uniform(0.7, 1.0)
            }
    
    # ---- PRODUCT CLASS ----
    class Product:
        def __init__(self, x=0, y=0, is_defective=False, defect_type=0):
            # Konum
            self.x = x
            self.y = y
            
            # Boyut
            self.width = 40
            self.height = 20
            
            # Ozellikler
            self.is_defective = is_defective
            self.defect_type = defect_type  # 0: Renk, 1: Leke, 2: Yapisal, 3: Kesim
            self.defect_severity = random.uniform(0.1, 1.0) if is_defective else 0.0
            
            # Durum
            self.scanned = False
            self.sorted = False
            self.sorted_as_defective = False
            
            # Gorsel
            self.image = self.generate_image()
        
        def generate_image(self):
            # Urun goruntusu olustur (OpenCV ile)
            img = np.ones((100, 200, 3), dtype=np.uint8) * 255  # Beyaz arka plan
            
            # Oval sekil ciz
            cv2.ellipse(img, (100, 50), (80, 40), 0, 0, 360, (240, 240, 240), -1)
            cv2.ellipse(img, (100, 50), (80, 40), 0, 0, 360, (200, 200, 200), 2)
            
            if self.is_defective:
                if self.defect_type == 0:  # Renk degisimi
                    # Sararmis bolge ekle
                    mask = np.zeros((100, 200), dtype=np.uint8)
                    cv2.ellipse(mask, (100, 50), (60, 30), 0, 0, 360, 255, -1)
                    yellow_intensity = int(100 * self.defect_severity)
                    img[mask > 0] = [255 - yellow_intensity, 255 - yellow_intensity, 255]
                    
                elif self.defect_type == 1:  # Leke
                    # Rastgele lekeler ekle
                    num_stains = int(1 + 5 * self.defect_severity)
                    for _ in range(num_stains):
                        x = random.randint(50, 150)
                        y = random.randint(30, 70)
                        radius = random.randint(2, 8)
                        color = (random.randint(100, 180), random.randint(100, 180), random.randint(100, 180))
                        cv2.circle(img, (x, y), radius, color, -1)
                        
                elif self.defect_type == 2:  # Yapisal bozulma
                    # Kenarlari deforme et
                    pts = np.array([[100, 10], [180, 50], [100, 90], [20, 50]], np.int32)
                    pts = pts.reshape((-1, 1, 2))
                    
                    # Deformasyon ekle
                    for i in range(len(pts)):
                        pts[i][0][0] += int(random.uniform(-20, 20) * self.defect_severity)
                        pts[i][0][1] += int(random.uniform(-10, 10) * self.defect_severity)
                    
                    # Yeni sekil ciz
                    img = np.ones((100, 200, 3), dtype=np.uint8) * 255
                    cv2.fillPoly(img, [pts], (240, 240, 240))
                    cv2.polylines(img, [pts], True, (200, 200, 200), 2)
                    
                elif self.defect_type == 3:  # Kesim hatasi
                    # Asimetrik kesim
                    img = np.ones((100, 200, 3), dtype=np.uint8) * 255
                    shift_x = int(20 * self.defect_severity)
                    shift_y = int(10 * self.defect_severity)
                    cv2.ellipse(img, (100 + shift_x, 50 + shift_y), (70, 35), 0, 0, 360, (240, 240, 240), -1)
                    cv2.ellipse(img, (100 + shift_x, 50 + shift_y), (70, 35), 0, 0, 360, (200, 200, 200), 2)
            
            # Pygame surface'e donustur
            img = cv2.resize(img, (self.width, self.height))
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            return pygame.surfarray.make_surface(img)
        
        def draw(self, screen):
            # Urunu ciz
            screen.blit(self.image, (self.x, self.y))
            
            # Tarandiysa goster
            if self.scanned:
                color = (255, 0, 0) if self.is_defective else (0, 255, 0)
                pygame.draw.rect(screen, color, (self.x, self.y, self.width, self.height), 1)
    
    class ProductGenerator:
        def __init__(self, screen):
            self.screen = screen
            self.last_generation_time = time.time()
            self.generation_interval = 2.0  # saniye
            self.defect_probability = 0.3  # %30 hatali urun
        
        def generate(self):
            current_time = time.time()
            if current_time - self.last_generation_time >= self.generation_interval:
                self.last_generation_time = current_time
                
                # Hatali mi belirle
                is_defective = random.random() < self.defect_probability
                
                # Hata turunu belirle
                defect_type = random.randint(0, 3) if is_defective else 0
                
                # Yeni urun olustur
                return Product(is_defective=is_defective, defect_type=defect_type)
            
            return None
        
        def reset(self):
            self.last_generation_time = time.time()
    
    # ---- CONVEYOR CLASS ----
    class Conveyor:
        def __init__(self, screen):
            self.screen = screen
            self.width = screen.get_width()
            self.height = screen.get_height()
            
            # Konveyor ozellikleri
            self.conveyor_x = 50
            self.conveyor_y = self.height // 2
            self.conveyor_width = self.width - 100
            self.conveyor_height = 50
            self.conveyor_color = (100, 100, 100)
            self.conveyor_speed = 2
            
            # Tarama noktasi
            self.scan_point_x = self.width // 2
            self.scan_distance = 20  # Tarama noktasi etrafindaki mesafe
            
            # Urunler
            self.products = []
        
        def add_product(self, product):
            # Yeni urun ekle
            product.x = self.conveyor_x
            product.y = self.conveyor_y - product.height // 2
            self.products.append(product)
        
        def move(self):
            # Tum urunleri hareket ettir
            for product in self.products[:]:
                product.x += self.conveyor_speed
                
                # Ekrandan cikan urunleri kaldir
                if product.x > self.width:
                    self.products.remove(product)
        
        def get_products_at_scan_point(self):
            # Tarama noktasindaki urunleri bul
            scan_products = []
            for product in self.products:
                if abs(product.x - self.scan_point_x) < self.scan_distance:
                    scan_products.append(product)
                    product.scanned = True
            return scan_products
        
        def clear(self):
            # Tum urunleri temizle
            self.products = []
        
        def draw(self):
            # Konveyor bandini ciz
            pygame.draw.rect(
                self.screen,
                self.conveyor_color,
                (self.conveyor_x, self.conveyor_y, self.conveyor_width, self.conveyor_height)
            )
            
            # Tarama noktasini ciz
            pygame.draw.line(
                self.screen,
                (255, 0, 0),
                (self.scan_point_x, self.conveyor_y - 50),
                (self.scan_point_x, self.conveyor_y + 50),
                2
            )
            
            # Urunleri ciz
            for product in self.products:
                product.draw(self.screen)
    
    # ---- SIMULATION CLASS ----
    class Simulation:
        def __init__(self):
            # Ekran ayarlari
            self.width = 1024
            self.height = 768
            self.screen = pygame.display.set_mode((self.width, self.height))
            pygame.display.set_caption("Medikal Urun Kalite Kontrolu Simulasyonu")
            
            # FPS kontrolu
            self.clock = pygame.time.Clock()
            self.fps = 60
            
            # Simulasyon bilesenleri
            self.conveyor = Conveyor(self.screen)
            self.product_generator = ProductGenerator(self.screen)
            self.image_processor = ImageProcessor()
            self.sorter = Sorter(self.screen)
            self.ui = UI(self.screen)
            self.stats = Stats()
            
            # Simulasyon durumu
            self.running = False
            self.error_threshold = 2.0  # Varsayilan %2
            
        def run(self):
            # Ana simulasyon dongusu
            game_exit = False
            
            while not game_exit:
                # Olaylari isle
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        game_exit = True
                    
                    # UI olaylarini isle
                    action = self.ui.handle_event(event)
                    if action == "start":
                        self.running = True
                    elif action == "stop":
                        self.running = False
                    elif action == "reset":
                        self.reset()
                    elif action == "threshold_changed":
                        self.error_threshold = self.ui.get_error_threshold()
                
                # Ekrani temizle
                self.screen.fill((240, 240, 240))
                
                # Simulasyon adimlarini calistir
                if self.running:
                    self.step()
                
                # UI'i ciz
                self.ui.draw(self.stats)
                
                # Ekrani guncelle
                pygame.display.flip()
                self.clock.tick(self.fps)
        
        def step(self):
            # Yeni urun olustur
            new_product = self.product_generator.generate()
            if new_product:
                self.conveyor.add_product(new_product)
            
            # Konveyor bandini hareket ettir
            self.conveyor.move()
            
            # Goruntu isleme noktasina gelen urunleri isle
            products_to_process = self.conveyor.get_products_at_scan_point()
            for product in products_to_process:
                # Goruntu isleme
                defect_info = self.image_processor.process(product)
                
                # Hata oranini kontrol et
                should_sort_as_defective = defect_info["defect_percentage"] > self.error_threshold
                
                # Ayristirma
                self.sorter.sort_product(product, should_sort_as_defective)
                
                # İstatistikleri guncelle
                self.stats.update(product.is_defective, should_sort_as_defective)
            
            # Konveyor ve ayristiriciyi ciz
            self.conveyor.draw()
            self.sorter.draw()
        
        def reset(self):
            # Simulasyonu sifirla
            self.running = False
            self.conveyor.clear()
            self.product_generator.reset()
            self.sorter.reset()
            self.stats.reset()
    
    # ---- MAIN FUNCTION ----
    def main():
        # Pygame baslat
        pygame.init()
        
        # Windows icin ozel ayarlar
        if os.name == 'nt':
            # Windows'ta daha iyi performans icin
            os.environ['SDL_VIDEODRIVER'] = 'windib'
        
        # Simulasyon olustur ve calistir
        sim = Simulation()
        sim.run()
        
        # Temizlik
        pygame.quit()
        sys.exit()
    
    if __name__ == "__main__":
        main()
except Exception as e:
    import traceback
    print("HATA OLUSTU:")
    traceback.print_exc()
